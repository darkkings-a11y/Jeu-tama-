package com.example.tamagotchi

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

fun hsv(h: Float, s: Float, v: Float): Int =
    Color.HSVToColor(floatArrayOf(((h % 360f) + 360f) % 360f, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f)))

fun mix(a: Int, b: Int, t: Float): Int {
    val u = t.coerceIn(0f, 1f)
    return Color.argb(
        (Color.alpha(a) * (1 - u) + Color.alpha(b) * u).toInt(),
        (Color.red(a) * (1 - u) + Color.red(b) * u).toInt(),
        (Color.green(a) * (1 - u) + Color.green(b) * u).toInt(),
        (Color.blue(a) * (1 - u) + Color.blue(b) * u).toInt()
    )
}

/** Tous les traits de la créature sortent d'une seule graine aléatoire. */
class Gene(seed: Long) {
    private val r = Random(seed)
    val hue = r.nextInt(360).toFloat()
    val sat = 0.45f + r.nextFloat() * 0.4f
    val shape = r.nextInt(5)      // 0 rond, 1 haut, 2 large, 3 carré arrondi, 4 goutte
    val eye = r.nextInt(5)        // 0 points, 1 gros brillants, 2 endormis, 3 chat, 4 cyclope
    val acc = r.nextInt(5)        // 0 rien, 1 cornes, 2 antenne, 3 oreilles pointues, 4 oreilles rondes
    val tail = r.nextFloat() < 0.5f
    val wings = r.nextFloat() < 0.3f
    val pattern = r.nextInt(4)    // 0 uni, 1 ventre, 2 taches, 3 rayures
    val cheeks = r.nextFloat() < 0.6f
    val accentHue = (hue + 120f + r.nextInt(120)) % 360f
    val eggHue = Random(seed xor 0x5DEECE66DL).nextInt(360).toFloat()
    val name: String

    init {
        val syl = listOf("ki", "mo", "ra", "pu", "zi", "lo", "ta", "nu", "be", "fi", "ko", "mi", "chi", "pa", "do", "su")
        val n = 2 + r.nextInt(2)
        name = (1..n).joinToString("") { syl[r.nextInt(syl.size)] }.replaceFirstChar { it.uppercase() }
    }
}

class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    var life: Float, val maxLife: Float, val text: String?,
    val color: Int, val size: Float, val grav: Float, val kind: Int
)

class GameView(context: Context) : View(context) {
    private val d = resources.displayMetrics.density
    private fun dp(v: Float) = v * d
    private val prefs = context.getSharedPreferences("tama", Context.MODE_PRIVATE)
    private val rnd = Random(System.nanoTime())

    // ---- Réglages de difficulté (modifiables) ----
    private val tapsToHatch = 8
    private val hungerRate = 0.35f   // faim perdue par seconde
    private val happyRate = 0.28f    // bonheur perdu par seconde
    private val energyRate = 0.12f   // énergie perdue par seconde

    // ---- Géométrie ----
    private var W = 0f
    private var H = 0f
    private var roomH = 0f
    private var floorY = 0f
    private var groundY = 0f
    private var u = 0f
    private val win = RectF()
    private val btn = Array(4) { RectF() }
    private val resetBtn = RectF()
    private var bg: Bitmap? = null

    // ---- Peintures ----
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }

    // ---- État du jeu ----
    private var seed = rnd.nextLong()
    private var gene = Gene(seed)
    private var stage = 0            // 0 œuf, 1 éclosion, 2 vivant
    private var taps = 0
    private var hatchT = 0f
    private var hunger = 80f
    private var happy = 80f
    private var health = 100f
    private var energy = 100f
    private var sleeping = false
    private var sick = false
    private val poops = ArrayList<Float>()
    private var poopTimer = 50f
    private var playT = 0f
    private var eatT = 0f
    private var cleanT = 0f
    private var petT = 0f
    private var shakeT = 0f
    private var flashT = 0f
    private var bornT = 0f
    private var nightA = 0f
    private var cx = 0f
    private var targetX = 0f
    private var dir = 1f
    private var waitT = 1f
    private var moving = false
    private var time = 0f
    private var msg = ""
    private var msgT = 0f
    private var resetArmT = 0f
    private var foodEmoji = "🍎"
    private var spawnT = 0f
    private val pressT = FloatArray(4)
    private val parts = ArrayList<Particle>()
    private var last = 0L

    private val btnColors = intArrayOf(0xFFFF8A65.toInt(), 0xFF4DD0E1.toInt(), 0xFF81C784.toInt(), 0xFFFFD54F.toInt())

    init {
        load()
    }

    // =========================================================== Sauvegarde

    fun save() {
        prefs.edit()
            .putLong("seed", seed)
            .putInt("stage", if (stage == 2) 2 else 0)
            .putInt("taps", if (stage == 1) tapsToHatch else taps)
            .putFloat("hunger", hunger)
            .putFloat("happy", happy)
            .putFloat("health", health)
            .putFloat("energy", energy)
            .putBoolean("sleeping", sleeping)
            .putBoolean("sick", sick)
            .putInt("poops", poops.size)
            .putLong("last", System.currentTimeMillis())
            .apply()
    }

    private fun load() {
        if (!prefs.contains("seed")) return
        seed = prefs.getLong("seed", seed)
        gene = Gene(seed)
        stage = prefs.getInt("stage", 0)
        taps = prefs.getInt("taps", 0)
        hunger = prefs.getFloat("hunger", 80f)
        happy = prefs.getFloat("happy", 80f)
        health = prefs.getFloat("health", 100f)
        energy = prefs.getFloat("energy", 100f)
        sleeping = prefs.getBoolean("sleeping", false)
        sick = prefs.getBoolean("sick", false)
        val n = prefs.getInt("poops", 0)
        for (i in 0 until n) poops.add(0.15f + rnd.nextFloat() * 0.7f)
        if (stage == 0 && taps >= tapsToHatch) {
            stage = 1
            hatchT = 0f
        }
        if (stage == 2) {
            val el = min((System.currentTimeMillis() - prefs.getLong("last", System.currentTimeMillis())) / 1000f, 900f) * 0.4f
            if (sleeping) {
                hunger -= 0.10f * el
                energy += 2.5f * el
            } else {
                hunger -= hungerRate * el
                happy -= happyRate * el
                energy -= energyRate * el
                val extra = (el / 60f).toInt()
                for (i in 0 until extra) if (poops.size < 3) poops.add(0.15f + rnd.nextFloat() * 0.7f)
            }
            hunger = hunger.coerceIn(10f, 100f)
            happy = happy.coerceIn(10f, 100f)
            energy = energy.coerceIn(0f, 100f)
            bornT = 10f
        }
    }

    private fun resetGame() {
        seed = rnd.nextLong()
        gene = Gene(seed)
        stage = 0
        taps = 0
        hatchT = 0f
        hunger = 80f
        happy = 80f
        health = 100f
        energy = 100f
        sleeping = false
        sick = false
        poops.clear()
        parts.clear()
        playT = 0f
        eatT = 0f
        cleanT = 0f
        petT = 0f
        nightA = 0f
        cx = W / 2f
        targetX = cx
        save()
    }

    // =========================================================== Taille / fond

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        W = w.toFloat()
        H = h.toFloat()
        roomH = H * 0.74f
        floorY = roomH * 0.64f
        groundY = roomH * 0.82f
        u = W * 0.115f
        cx = W / 2f
        targetX = cx
        win.set(W * 0.10f, roomH * 0.15f, W * 0.40f, roomH * 0.38f)
        val gap = dp(10f)
        val bw = (W - gap * 5f) / 4f
        val top = roomH + gap + dp(4f)
        val bh = H - top - gap - dp(14f)
        for (i in 0..3) btn[i].set(gap + (bw + gap) * i, top, gap + (bw + gap) * i + bw, top + bh)
        val rr = dp(16f)
        resetBtn.set(W - dp(12f) - rr * 2, dp(30f) + dp(44f) + dp(8f), W - dp(12f), dp(30f) + dp(44f) + dp(8f) + rr * 2)
        buildBg()
    }

    private fun buildBg() {
        if (W < 1f || roomH < 1f) return
        bg?.recycle()
        val b = Bitmap.createBitmap(W.toInt(), roomH.toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        // mur
        fill.color = 0xFFFBE9C6.toInt()
        c.drawRect(0f, 0f, W, floorY, fill)
        val sw = dp(40f)
        var x = 0f
        var k = 0
        while (x < W) {
            if (k % 2 == 0) {
                fill.color = 0x22F4A261
                c.drawRect(x, 0f, x + sw, floorY, fill)
            }
            x += sw
            k++
        }
        fill.color = 0x55F48FB1
        var row = 0
        var y = dp(20f)
        while (y < floorY - dp(14f)) {
            var xx = if (row % 2 == 0) dp(20f) else dp(40f)
            while (xx < W) {
                c.drawCircle(xx, y, dp(3f), fill)
                xx += sw
            }
            y += dp(34f)
            row++
        }
        // plancher
        fill.color = 0xFFC98B4F.toInt()
        c.drawRect(0f, floorY, W, roomH, fill)
        line.color = 0xFF9C6232.toInt()
        line.strokeWidth = dp(2f)
        val ph = (roomH - floorY) / 5f
        for (i in 1..5) {
            val yy = floorY + ph * i
            c.drawLine(0f, yy, W, yy, line)
            var jx = if (i % 2 == 0) dp(30f) else dp(110f)
            while (jx < W) {
                c.drawLine(jx, yy - ph, jx, yy, line)
                jx += dp(160f)
            }
        }
        // plinthe
        fill.color = 0xFF8B5A2B.toInt()
        c.drawRect(0f, floorY - dp(4f), W, floorY + dp(10f), fill)
        // tapis
        fill.color = 0xFFE57373.toInt()
        c.drawOval(RectF(W / 2f - u * 2.3f, groundY - u * 0.25f, W / 2f + u * 2.3f, groundY + u * 0.55f), fill)
        fill.color = 0xFFFFCDD2.toInt()
        c.drawOval(RectF(W / 2f - u * 1.9f, groundY - u * 0.15f, W / 2f + u * 1.9f, groundY + u * 0.45f), fill)
        // cadre au mur
        val fr = RectF(W * 0.60f, roomH * 0.17f, W * 0.86f, roomH * 0.36f)
        fill.color = 0xFF8B5A2B.toInt()
        c.drawRoundRect(fr, dp(6f), dp(6f), fill)
        fill.color = 0xFFB3E5FC.toInt()
        c.drawRect(fr.left + dp(8f), fr.top + dp(8f), fr.right - dp(8f), fr.bottom - dp(8f), fill)
        emoji(c, "🌸", fr.centerX(), fr.centerY(), fr.height() * 0.5f)
        // plante
        val px = W * 0.89f
        fill.color = 0xFF43A047.toInt()
        for (i in -2..2) {
            c.save()
            c.translate(px, groundY - u * 0.55f)
            c.rotate(i * 28f)
            c.drawOval(RectF(-u * 0.16f, -u * 0.95f, u * 0.16f, 0f), fill)
            c.restore()
        }
        fill.color = 0xFFD2693C.toInt()
        val pot = Path()
        pot.moveTo(px - u * 0.45f, groundY - u * 0.6f)
        pot.lineTo(px + u * 0.45f, groundY - u * 0.6f)
        pot.lineTo(px + u * 0.32f, groundY + u * 0.1f)
        pot.lineTo(px - u * 0.32f, groundY + u * 0.1f)
        pot.close()
        c.drawPath(pot, fill)
        bg = b
    }

    // =========================================================== Boucle

    override fun onDraw(c: Canvas) {
        val now = SystemClock.uptimeMillis()
        var dt = if (last == 0L) 0f else (now - last) / 1000f
        last = now
        dt = min(dt, 0.05f)
        if (W > 0f) {
            update(dt)
            render(c)
        }
        postInvalidateOnAnimation()
    }

    private fun say(s: String) {
        msg = s
        msgT = 2.4f
    }

    private fun burst(text: String?, x: Float, y: Float, n: Int, speed: Float, color: Int, size: Float, grav: Float, kind: Int) {
        for (i in 0 until n) {
            val a = rnd.nextFloat() * 6.2831f
            val sp = speed * (0.4f + rnd.nextFloat() * 0.8f)
            val l = 0.8f + rnd.nextFloat() * 0.8f
            parts.add(Particle(x, y, kotlin.math.cos(a) * sp, kotlin.math.sin(a) * sp - speed * 0.5f, l, l, text, color, size, grav, kind))
        }
    }

    private fun mood(): Int = when {
        sleeping -> 3
        sick -> 4
        playT > 0f || petT > 0f -> 2
        eatT > 0f -> 5
        hunger < 30f || happy < 30f || health < 50f -> 1
        else -> 0
    }

    private fun update(dt: Float) {
        time += dt
        if (msgT > 0f) msgT -= dt
        if (resetArmT > 0f) resetArmT -= dt
        if (shakeT > 0f) shakeT -= dt
        if (flashT > 0f) flashT -= dt
        for (i in pressT.indices) if (pressT[i] > 0f) pressT[i] -= dt
        nightA += ((if (sleeping && stage == 2) 0.58f else 0f) - nightA) * min(1f, dt * 3f)

        var i = parts.size - 1
        while (i >= 0) {
            val p = parts[i]
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vy += p.grav * dt
            p.life -= dt
            if (p.life <= 0f) parts.removeAt(i)
            i--
        }

        if (stage == 1) {
            hatchT += dt
            if (hatchT >= 1.0f) hatch()
            return
        }
        if (stage != 2) return

        bornT += dt
        if (playT > 0f) {
            playT -= dt
            spawnT -= dt
            if (spawnT <= 0f) {
                spawnT = 0.18f
                burst("❤️", cx, groundY - u * 2.2f, 1, u * 0.8f, Color.WHITE, dp(22f), 120f, 0)
            }
        }
        if (eatT > 0f) eatT -= dt
        if (petT > 0f) petT -= dt
        if (cleanT > 0f) {
            cleanT -= dt
            spawnT -= dt
            if (spawnT <= 0f) {
                spawnT = 0.07f
                parts.add(Particle(W * (0.1f + rnd.nextFloat() * 0.8f), groundY + u * 0.2f, 0f, -u * 1.2f, 1f, 1f, null, Color.WHITE, dp(6f + rnd.nextFloat() * 8f), 0f, 2))
            }
            if (cleanT < 0.7f && poops.isNotEmpty()) {
                poops.clear()
                happy += 8f
                burst("✨", cx, groundY - u, 6, u * 1.5f, Color.WHITE, dp(20f), 60f, 0)
            }
        }

        if (!sleeping) {
            hunger -= hungerRate * dt
            happy -= happyRate * dt
            energy -= energyRate * dt
            poopTimer -= dt
            if (poopTimer <= 0f) {
                if (poops.size < 3) poops.add(0.15f + rnd.nextFloat() * 0.7f)
                poopTimer = 50f + rnd.nextFloat() * 50f
            }
        } else {
            hunger -= 0.10f * dt
            happy -= 0.05f * dt
            energy += 2.5f * dt
        }
        var dh = 0f
        if (hunger < 15f) dh -= 0.6f
        if (happy < 15f) dh -= 0.2f
        dh -= 0.15f * poops.size
        if (sick) dh -= 0.05f
        if (hunger > 40f && happy > 40f && poops.isEmpty()) dh += 0.25f
        if (sleeping) dh += 0.3f
        health += dh * dt
        hunger = hunger.coerceIn(0f, 100f)
        happy = happy.coerceIn(0f, 100f)
        energy = energy.coerceIn(0f, 100f)
        health = health.coerceIn(0f, 100f)
        if (!sick && health < 30f) {
            sick = true
            say("Il est malade ! 🤒 Soigne-le (bouton 💊)")
        }
        if (sick && health >= 50f) sick = false

        // déplacement
        moving = false
        val canMove = !sleeping && !sick && eatT <= 0f && playT <= 0f && petT <= 0f
        if (canMove) {
            if (waitT > 0f) {
                waitT -= dt
            } else {
                val sp = u * (if (mood() == 1) 0.5f else 0.9f)
                val dx = targetX - cx
                if (abs(dx) < 4f) {
                    waitT = 1f + rnd.nextFloat() * 2.5f
                    targetX = W * (0.30f + rnd.nextFloat() * 0.40f)
                } else {
                    dir = if (dx > 0f) 1f else -1f
                    cx += dir * min(sp * dt, abs(dx))
                    moving = true
                }
            }
        }
    }

    private fun hatch() {
        stage = 2
        bornT = 0f
        flashT = 0.6f
        hunger = 80f
        happy = 80f
        health = 100f
        energy = 100f
        cx = W / 2f
        targetX = cx
        waitT = 2f
        poopTimer = 50f
        burst("⭐", W / 2f, groundY - u * 1.2f, 8, u * 3f, Color.WHITE, dp(24f), 200f, 0)
        burst("✨", W / 2f, groundY - u * 1.2f, 6, u * 2.5f, Color.WHITE, dp(22f), 100f, 0)
        burst(null, W / 2f, groundY - u * 1.0f, 14, u * 3.5f, hsv(gene.eggHue, 0.3f, 1f), dp(7f), 600f, 1)
        say("${gene.name} vient de naître !")
        save()
    }

    // =========================================================== Actions

    private fun feed() {
        if (sleeping) { say("Chut… il dort 💤"); return }
        if (sick) {
            health = min(100f, health + 25f)
            hunger = min(100f, hunger + 10f)
            eatT = 1.6f
            foodEmoji = "💊"
            say("Médicament avalé 💊")
            return
        }
        if (hunger >= 95f) { say("Il n'a plus faim !"); return }
        hunger = min(100f, hunger + 30f)
        eatT = 1.6f
        foodEmoji = listOf("🍎", "🍖", "🍙", "🍓").random(rnd)
        poopTimer = min(poopTimer, 20f + rnd.nextFloat() * 20f)
        say("Miam ! 😋")
    }

    private fun play() {
        if (sleeping) { say("Chut… il dort 💤"); return }
        if (sick) { say("Il est trop malade pour jouer 🤒"); return }
        if (energy < 15f) { say("Trop fatigué… éteins la lumière 🌙"); return }
        happy = min(100f, happy + 25f)
        hunger = max(0f, hunger - 6f)
        energy = max(0f, energy - 12f)
        playT = 2.2f
        say("Youpi ! 🎾")
    }

    private fun clean() {
        if (poops.isEmpty() && cleanT <= 0f) { say("C'est déjà tout propre ✨"); return }
        if (cleanT <= 0f) cleanT = 1.4f
    }

    private fun toggleLight() {
        sleeping = !sleeping
        say(if (sleeping) "Bonne nuit 🌙" else "Bonjour ! ☀️")
    }

    private fun handleTap(x: Float, y: Float) {
        if (resetBtn.contains(x, y)) {
            if (resetArmT > 0f) {
                resetGame()
                say("Un nouvel œuf !")
            } else {
                resetArmT = 3f
                say("Touche ↻ encore pour un nouvel œuf")
            }
            return
        }
        for (i in 0..3) {
            if (btn[i].contains(x, y)) {
                pressT[i] = 0.15f
                if (stage != 2) { say("Fais d'abord éclore l'œuf !"); return }
                when (i) {
                    0 -> feed()
                    1 -> play()
                    2 -> clean()
                    3 -> toggleLight()
                }
                return
            }
        }
        val hit = y > groundY - u * 2.6f && y < groundY + u * 0.4f
        if (stage == 0 && hit && abs(x - W / 2f) < u * 1.5f) {
            taps++
            shakeT = 0.5f
            burst("✨", W / 2f, groundY - u * 1.5f, 2, u * 1.5f, Color.WHITE, dp(16f), 100f, 0)
            if (taps >= tapsToHatch) {
                stage = 1
                hatchT = 0f
            }
        } else if (stage == 2 && !sleeping && hit && abs(x - cx) < u * 1.5f) {
            petT = 1.0f
            happy = min(100f, happy + 3f)
            burst("❤️", cx, groundY - u * 2f, 2, u * 0.8f, Color.WHITE, dp(20f), 120f, 0)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) handleTap(e.x, e.y)
        return true
    }

    // =========================================================== Dessin utilitaires

    private fun emoji(c: Canvas, s: String, x: Float, y: Float, size: Float, alpha: Int = 255) {
        txt.textSize = size
        txt.typeface = Typeface.DEFAULT
        txt.color = Color.WHITE
        txt.alpha = alpha
        val fm = txt.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, txt)
        txt.alpha = 255
    }

    private fun label(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = false, alpha: Int = 255) {
        txt.textSize = size
        txt.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        txt.color = color
        txt.alpha = alpha
        val fm = txt.fontMetrics
        c.drawText(s, x, y - (fm.ascent + fm.descent) / 2f, txt)
        txt.alpha = 255
    }

    private fun easeBack(t: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val k = t - 1f
        return 1f + c3 * k * k * k + c1 * k * k
    }

    private fun dims(shape: Int): FloatArray = when (shape) {
        0 -> floatArrayOf(u, 1.9f * u)
        1 -> floatArrayOf(0.8f * u, 2.3f * u)
        2 -> floatArrayOf(1.25f * u, 1.5f * u)
        3 -> floatArrayOf(0.95f * u, 1.8f * u)
        else -> floatArrayOf(u, 1.95f * u)
    }

    private fun bodyPath(shape: Int, bw: Float, bh: Float): Path {
        val p = Path()
        when (shape) {
            0, 1, 2 -> p.addOval(RectF(-bw, -bh, bw, 0f), Path.Direction.CW)
            3 -> p.addRoundRect(RectF(-bw, -bh, bw, 0f), bw * 0.55f, bw * 0.55f, Path.Direction.CW)
            else -> {
                p.moveTo(0f, -bh)
                p.cubicTo(bw * 0.3f, -bh, bw, -bh * 0.45f, bw, -bh * 0.25f)
                p.cubicTo(bw, 0f, -bw, 0f, -bw, -bh * 0.25f)
                p.cubicTo(-bw, -bh * 0.45f, -bw * 0.3f, -bh, 0f, -bh)
                p.close()
            }
        }
        return p
    }

    private fun topY(shape: Int, x: Float, bw: Float, bh: Float): Float {
        val k = (x / bw).coerceIn(-1f, 1f)
        return when (shape) {
            3 -> -bh + bw * 0.12f * k * k
            4 -> -bh / 2f - bh / 2f * sqrt(1f - k * k) + bh * 0.1f
            else -> -bh / 2f - bh / 2f * sqrt(1f - k * k)
        }
    }

    // =========================================================== Rendu

    private fun render(c: Canvas) {
        bg?.let { c.drawBitmap(it, 0f, 0f, null) }

        // poops
        for (px in poops) {
            val x = W * px
            emoji(c, "💩", x, groundY + u * 0.1f + sin(time * 3f + px * 10f) * dp(2f), dp(30f))
        }
        when (stage) {
            0, 1 -> drawEgg(c)
            else -> drawCreature(c)
        }

        // éponge de nettoyage
        if (cleanT > 0f) {
            val ph = 1f - cleanT / 1.4f
            val sx = W * (0.15f + 0.7f * (0.5f + 0.5f * sin(ph * 12f)))
            emoji(c, "🧽", sx, groundY + u * 0.1f, dp(40f))
        }

        // nuit
        if (nightA > 0.01f) {
            fill.color = Color.argb((nightA * 255).toInt(), 8, 14, 50)
            c.drawRect(0f, 0f, W, roomH, fill)
        }
        drawWindow(c)

        if (stage == 2 && sleeping) drawZzz(c)

        for (p in parts) {
            val a = ((p.life / p.maxLife).coerceIn(0f, 1f) * 255).toInt()
            when (p.kind) {
                0 -> emoji(c, p.text ?: "", p.x, p.y, p.size, a)
                1 -> {
                    fill.color = p.color
                    fill.alpha = a
                    c.drawCircle(p.x, p.y, p.size, fill)
                }
                else -> {
                    line.color = Color.WHITE
                    line.alpha = a
                    line.strokeWidth = dp(2f)
                    c.drawCircle(p.x, p.y, p.size, line)
                }
            }
        }
        fill.alpha = 255
        line.alpha = 255

        if (flashT > 0f) {
            fill.color = Color.argb((flashT / 0.6f * 230).toInt().coerceIn(0, 255), 255, 255, 255)
            c.drawRect(0f, 0f, W, roomH, fill)
        }

        drawHud(c)
        drawPanel(c)
        drawMessage(c)
    }

    private fun drawWindow(c: Canvas) {
        val n = (nightA / 0.58f).coerceIn(0f, 1f)
        val r = win
        fill.color = mix(0xFF8FD8FF.toInt(), 0xFF0D1440.toInt(), n)
        c.drawRoundRect(r, dp(6f), dp(6f), fill)
        c.save()
        c.clipRect(r)
        if (n < 0.95f) {
            fill.color = 0xFFFFE066.toInt()
            fill.alpha = ((1f - n) * 255).toInt()
            c.drawCircle(r.right - r.width() * 0.25f, r.top + r.height() * 0.3f, r.width() * 0.13f, fill)
            val cwid = r.width() * 0.4f
            val cxp = r.left + ((time * 8f) % (r.width() + cwid)) - cwid * 0.5f
            fill.color = Color.WHITE
            fill.alpha = ((1f - n) * 230).toInt()
            c.drawOval(RectF(cxp - cwid / 2f, r.top + r.height() * 0.55f, cxp + cwid / 2f, r.top + r.height() * 0.75f), fill)
            fill.alpha = 255
        }
        if (n > 0.05f) {
            fill.color = Color.WHITE
            fill.alpha = (n * 255).toInt()
            val mx = r.left + r.width() * 0.7f
            val my = r.top + r.height() * 0.32f
            c.drawCircle(mx, my, r.width() * 0.13f, fill)
            fill.color = mix(0xFF8FD8FF.toInt(), 0xFF0D1440.toInt(), n)
            c.drawCircle(mx + r.width() * 0.07f, my - r.width() * 0.03f, r.width() * 0.11f, fill)
            for (i in 0..5) {
                val sx = r.left + r.width() * (0.12f + 0.14f * i)
                val sy = r.top + r.height() * (0.15f + 0.5f * (((i * 37) % 10) / 10f))
                fill.color = Color.WHITE
                fill.alpha = (n * 255 * (0.5f + 0.5f * sin(time * 3f + i))).toInt().coerceIn(0, 255)
                c.drawCircle(sx, sy, dp(1.6f), fill)
            }
            fill.alpha = 255
        }
        c.restore()
        line.color = Color.WHITE
        line.strokeWidth = dp(5f)
        c.drawRoundRect(r, dp(6f), dp(6f), line)
        line.strokeWidth = dp(3f)
        c.drawLine(r.centerX(), r.top, r.centerX(), r.bottom, line)
        c.drawLine(r.left, r.centerY(), r.right, r.centerY(), line)
        // rideaux
        fill.color = 0xFFF48FB1.toInt()
        c.drawRoundRect(RectF(r.left - dp(10f), r.top - dp(10f), r.left + r.width() * 0.2f, r.bottom + dp(6f)), dp(8f), dp(8f), fill)
        c.drawRoundRect(RectF(r.right - r.width() * 0.2f, r.top - dp(10f), r.right + dp(10f), r.bottom + dp(6f)), dp(8f), dp(8f), fill)
        fill.color = 0xFF8B5A2B.toInt()
        c.drawRect(r.left - dp(14f), r.bottom + dp(6f), r.right + dp(14f), r.bottom + dp(12f), fill)
    }

    private fun drawEgg(c: Canvas) {
        val e = u
        val frozen = stage == 1
        val ang = when {
            frozen -> 0f
            shakeT > 0f -> sin(time * 38f) * 12f * (shakeT / 0.5f).coerceIn(0f, 1f)
            else -> sin(time * 2f) * 1.5f
        }
        val sq = 1f + (if (frozen) 0f else 0.02f * sin(time * 3f))
        fill.color = Color.argb(70, 0, 0, 0)
        c.drawOval(RectF(W / 2f - e * 0.9f, groundY - e * 0.1f, W / 2f + e * 0.9f, groundY + e * 0.2f), fill)
        if (frozen) {
            val a = hatchT.coerceIn(0f, 1f)
            for (k in 1..4) {
                fill.color = Color.argb((a * 45).toInt(), 255, 240, 150)
                c.drawCircle(W / 2f, groundY - e, e * (1.2f + k * 0.35f + 0.08f * sin(time * 20f)), fill)
            }
        }
        c.save()
        c.translate(W / 2f, groundY)
        c.rotate(ang)
        c.scale(1f, sq)
        val p = Path()
        p.moveTo(0f, -2.15f * e)
        p.cubicTo(0.65f * e, -2.15f * e, e, -1.2f * e, e, -0.8f * e)
        p.cubicTo(e, -0.3f * e, 0.55f * e, 0f, 0f, 0f)
        p.cubicTo(-0.55f * e, 0f, -e, -0.3f * e, -e, -0.8f * e)
        p.cubicTo(-e, -1.2f * e, -0.65f * e, -2.15f * e, 0f, -2.15f * e)
        p.close()
        fill.color = 0xFFFFF4DA.toInt()
        c.drawPath(p, fill)
        c.save()
        c.clipPath(p)
        fill.color = hsv(gene.eggHue, 0.5f, 0.95f)
        c.drawCircle(-0.5f * e, -1.5f * e, 0.22f * e, fill)
        c.drawCircle(0.45f * e, -1.2f * e, 0.28f * e, fill)
        c.drawCircle(-0.2f * e, -0.6f * e, 0.2f * e, fill)
        c.drawCircle(0.5f * e, -0.45f * e, 0.17f * e, fill)
        c.drawCircle(0f, -1.95f * e, 0.15f * e, fill)
        c.drawCircle(-0.75f * e, -0.9f * e, 0.15f * e, fill)
        c.restore()
        line.color = 0xFFC9A66B.toInt()
        line.strokeWidth = dp(3f)
        c.drawPath(p, line)
        // fissures
        val px = floatArrayOf(-0.1f, 0.1f, -0.15f, 0.2f, -0.2f, 0.15f, -0.1f, 0.1f)
        val py = floatArrayOf(-1.7f, -1.45f, -1.25f, -1.05f, -0.85f, -0.65f, -0.45f, -0.25f)
        val segs = min(taps, 7)
        for (i in 0 until segs) {
            if (frozen) {
                line.color = 0xFFFFF176.toInt()
                line.strokeWidth = dp(7f)
                c.drawLine(px[i] * e, py[i] * e, px[i + 1] * e, py[i + 1] * e, line)
            }
            line.color = 0xFF5D4037.toInt()
            line.strokeWidth = dp(2.5f)
            c.drawLine(px[i] * e, py[i] * e, px[i + 1] * e, py[i + 1] * e, line)
        }
        c.restore()
        if (stage == 0) {
            val pulse = 1f + 0.06f * sin(time * 4f)
            label(c, "Touche l'œuf !  $taps/$tapsToHatch", W / 2f, groundY + u * 0.9f, dp(16f) * pulse, 0xFF5D3A1A.toInt(), true)
        }
    }

    private fun drawCreature(c: Canvas) {
        val g = gene
        val m = mood()
        val s = u
        val dm = dims(g.shape)
        val bw = dm[0]
        val bh = dm[1]
        val bs = easeBack((bornT / 0.6f).coerceIn(0f, 1f))
        var jump = 0f
        if (playT > 0f) jump = abs(sin(time * 9f)) * s * 0.9f
        else if (petT > 0f) jump = abs(sin(time * 14f)) * s * 0.4f
        else if (moving) jump = abs(sin(time * 8f)) * s * 0.12f
        val breathe = 1f + 0.035f * sin(time * (if (m == 3) 1.6f else 3.2f))

        val shw = bw * 0.95f * bs * (1f - jump / (s * 3f))
        fill.color = Color.argb(70, 0, 0, 0)
        c.drawOval(RectF(cx - shw, groundY - s * 0.08f, cx + shw, groundY + s * 0.2f), fill)

        c.save()
        c.translate(cx, groundY - jump)
        c.scale(bs * (2f - breathe), bs * breathe)

        val dark = hsv(g.hue, g.sat + 0.25f, 0.55f)
        var bodyCol = hsv(g.hue, g.sat, 0.95f)
        if (m == 4) bodyCol = mix(bodyCol, 0xFF9CCC65.toInt(), 0.5f)
        val light = mix(bodyCol, Color.WHITE, 0.55f)
        val accent = hsv(g.accentHue, 0.7f, 0.95f)
        val fx = dir * bw * 0.12f
        line.strokeWidth = max(dp(2f), s * 0.05f)
        line.color = dark

        // ailes
        if (g.wings) {
            val flap = if (m == 3) 0f else sin(time * (if (moving || playT > 0f) 14f else 5f)) * 25f
            for (sx in intArrayOf(-1, 1)) {
                c.save()
                c.translate(sx * bw * 0.92f, -bh * 0.58f)
                c.rotate(sx * (-25f - flap))
                val mid = sx * 0.3f * s
                val rc = RectF(mid - 0.32f * s, -0.2f * s, mid + 0.32f * s, 0.2f * s)
                fill.color = mix(accent, Color.WHITE, 0.4f)
                c.drawOval(rc, fill)
                c.drawOval(rc, line)
                c.restore()
            }
        }
        // queue
        if (g.tail) {
            val wag = if (m == 3) 0f else sin(time * 6f) * 20f
            c.save()
            c.translate(-dir * bw * 0.92f, -bh * 0.2f)
            c.rotate(wag)
            val mid = -dir * 0.4f * s
            val rc = RectF(mid - 0.42f * s, -0.17f * s, mid + 0.42f * s, 0.17f * s)
            fill.color = accent
            c.drawOval(rc, fill)
            c.drawOval(rc, line)
            c.restore()
        }
        // pieds
        fill.color = dark
        c.drawOval(RectF(-bw * 0.5f - 0.32f * s, -0.25f * s, -bw * 0.5f + 0.32f * s, 0.15f * s), fill)
        c.drawOval(RectF(bw * 0.5f - 0.32f * s, -0.25f * s, bw * 0.5f + 0.32f * s, 0.15f * s), fill)

        // accessoires (derrière le corps)
        when (g.acc) {
            1 -> for (sx in intArrayOf(-1, 1)) {
                val x = sx * bw * 0.5f
                val ty = topY(g.shape, x, bw, bh) + s * 0.1f
                val hp = Path()
                hp.moveTo(x - 0.2f * s, ty)
                hp.lineTo(x + sx * 0.25f * s, ty - 0.6f * s)
                hp.lineTo(x + 0.2f * s, ty)
                hp.close()
                fill.color = accent
                c.drawPath(hp, fill)
                c.drawPath(hp, line)
            }
            2 -> {
                val ty = topY(g.shape, 0f, bw, bh) + s * 0.1f
                val tipX = sin(time * 3f) * 0.15f * s
                val tipY = -bh - 0.75f * s
                val ap = Path()
                ap.moveTo(0f, ty)
                ap.quadTo(0.3f * s, -bh - 0.3f * s, tipX, tipY)
                c.drawPath(ap, line)
                fill.color = accent
                c.drawCircle(tipX, tipY, 0.17f * s, fill)
                c.drawCircle(tipX, tipY, 0.17f * s, line)
            }
            3 -> for (sx in intArrayOf(-1, 1)) {
                val x = sx * bw * 0.62f
                val ty = topY(g.shape, x, bw, bh) + s * 0.15f
                val ep = Path()
                ep.moveTo(x - 0.3f * s, ty)
                ep.lineTo(x + sx * 0.45f * s, ty - 0.75f * s)
                ep.lineTo(x + 0.3f * s, ty)
                ep.close()
                fill.color = bodyCol
                c.drawPath(ep, fill)
                c.drawPath(ep, line)
                val ip = Path()
                ip.moveTo(x - 0.15f * s, ty)
                ip.lineTo(x + sx * 0.38f * s, ty - 0.5f * s)
                ip.lineTo(x + 0.15f * s, ty)
                ip.close()
                fill.color = 0xFFFFB3C1.toInt()
                c.drawPath(ip, fill)
            }
            4 -> for (sx in intArrayOf(-1, 1)) {
                val x = sx * bw * 0.68f
                val ty = topY(g.shape, x, bw, bh) + s * 0.05f
                fill.color = bodyCol
                c.drawCircle(x, ty, 0.32f * s, fill)
                c.drawCircle(x, ty, 0.32f * s, line)
                fill.color = 0xFFFFB3C1.toInt()
                c.drawCircle(x, ty, 0.18f * s, fill)
            }
        }

        // corps
        val body = bodyPath(g.shape, bw, bh)
        fill.color = bodyCol
        c.drawPath(body, fill)
        c.save()
        c.clipPath(body)
        when (g.pattern) {
            1 -> {
                fill.color = light
                c.drawOval(RectF(-bw * 0.62f, -bh * 0.52f, bw * 0.62f, bh * 0.05f), fill)
            }
            2 -> {
                fill.color = mix(bodyCol, dark, 0.35f)
                c.drawCircle(-bw * 0.5f, -bh * 0.3f, s * 0.22f, fill)
                c.drawCircle(bw * 0.45f, -bh * 0.22f, s * 0.17f, fill)
                c.drawCircle(-bw * 0.2f, -bh * 0.12f, s * 0.14f, fill)
                c.drawCircle(bw * 0.5f, -bh * 0.85f, s * 0.15f, fill)
            }
            3 -> {
                fill.color = mix(bodyCol, dark, 0.3f)
                for (i in 0..2) {
                    val y = -bh * (0.14f + 0.14f * i)
                    c.drawRect(-bw, y, bw, y + s * 0.13f, fill)
                }
            }
        }
        c.restore()
        c.drawPath(body, line)

        // visage
        val ey = -bh * 0.62f
        val ex = bw * 0.4f
        val r = s * 0.17f
        val eyeDark = Color.rgb(40, 30, 50)
        val blink = (time % 4f) < 0.12f
        val xs = if (g.eye == 4) floatArrayOf(fx) else floatArrayOf(fx - ex, fx + ex)
        for ((idx, x) in xs.withIndex()) {
            line.color = eyeDark
            line.strokeWidth = max(dp(2f), s * 0.06f)
            fill.color = eyeDark
            when {
                m == 3 -> c.drawArc(RectF(x - r, ey - r * 0.6f, x + r, ey + r * 0.6f), 0f, 180f, false, line)
                blink -> c.drawLine(x - r, ey, x + r, ey, line)
                m == 2 -> c.drawArc(RectF(x - r * 1.1f, ey - r * 0.4f, x + r * 1.1f, ey + r * 1.4f), 180f, 180f, false, line)
                m == 4 -> {
                    c.drawLine(x - r, ey - r, x + r, ey + r, line)
                    c.drawLine(x - r, ey + r, x + r, ey - r, line)
                }
                else -> {
                    when (g.eye) {
                        0 -> {
                            c.drawCircle(x, ey, r, fill)
                            fill.color = Color.WHITE
                            c.drawCircle(x - r * 0.3f, ey - r * 0.3f, r * 0.35f, fill)
                        }
                        1 -> {
                            fill.color = Color.WHITE
                            c.drawCircle(x, ey, r * 1.6f, fill)
                            c.drawCircle(x, ey, r * 1.6f, line)
                            fill.color = eyeDark
                            c.drawCircle(x + dir * r * 0.3f, ey, r, fill)
                            fill.color = Color.WHITE
                            c.drawCircle(x + dir * r * 0.3f - r * 0.3f, ey - r * 0.3f, r * 0.35f, fill)
                        }
                        2 -> {
                            c.drawCircle(x, ey, r * 1.1f, fill)
                            fill.color = bodyCol
                            c.drawRect(x - r * 1.4f, ey - r * 1.4f, x + r * 1.4f, ey, fill)
                            c.drawLine(x - r * 1.2f, ey, x + r * 1.2f, ey, line)
                        }
                        3 -> {
                            fill.color = 0xFFFFE066.toInt()
                            val er = RectF(x - r * 1.2f, ey - r * 1.4f, x + r * 1.2f, ey + r * 1.4f)
                            c.drawOval(er, fill)
                            c.drawOval(er, line)
                            fill.color = eyeDark
                            c.drawOval(RectF(x - r * 0.3f + dir * r * 0.2f, ey - r * 1.3f, x + r * 0.3f + dir * r * 0.2f, ey + r * 1.3f), fill)
                        }
                        else -> {
                            fill.color = Color.WHITE
                            c.drawCircle(x, ey, r * 2.3f, fill)
                            c.drawCircle(x, ey, r * 2.3f, line)
                            fill.color = eyeDark
                            c.drawCircle(x + dir * r * 0.5f, ey, r * 1.2f, fill)
                            fill.color = Color.WHITE
                            c.drawCircle(x + dir * r * 0.5f - r * 0.35f, ey - r * 0.4f, r * 0.4f, fill)
                        }
                    }
                    if (m == 1 && idx == 0) {
                        val dy = ((time * 1.5f) % 1f) * r * 1.5f
                        fill.color = 0xFF4FC3F7.toInt()
                        c.drawOval(RectF(x - r * 0.35f, ey + r * 1.8f + dy, x + r * 0.35f, ey + r * 2.8f + dy), fill)
                    }
                }
            }
        }
        // joues
        if (g.cheeks && g.eye != 4) {
            fill.color = Color.argb(130, 255, 143, 163)
            c.drawCircle(fx - ex - r * 1.4f, ey + r * 2.2f, s * 0.15f, fill)
            c.drawCircle(fx + ex + r * 1.4f, ey + r * 2.2f, s * 0.15f, fill)
        }
        // bouche
        val my = -bh * 0.42f
        line.color = eyeDark
        line.strokeWidth = max(dp(2f), s * 0.06f)
        fill.color = eyeDark
        when (m) {
            3 -> {
                val rr = s * (0.06f + 0.03f * sin(time * 1.6f))
                c.drawOval(RectF(fx - rr, my - rr, fx + rr, my + rr * 1.3f), fill)
            }
            5 -> {
                val rr = s * (0.1f + 0.1f * abs(sin(time * 12f)))
                c.drawOval(RectF(fx - rr, my - rr * 0.6f, fx + rr, my + rr), fill)
            }
            2 -> {
                c.drawArc(RectF(fx - 0.3f * s, my - 0.15f * s, fx + 0.3f * s, my + 0.3f * s), 0f, 180f, true, fill)
                fill.color = 0xFFFF8FA3.toInt()
                c.drawCircle(fx, my + 0.2f * s, 0.08f * s, fill)
            }
            1 -> c.drawArc(RectF(fx - 0.22f * s, my + 0.1f * s, fx + 0.22f * s, my + 0.4f * s), 200f, 140f, false, line)
            4 -> {
                val wp = Path()
                wp.moveTo(fx - 0.25f * s, my + 0.05f * s)
                wp.quadTo(fx - 0.12f * s, my - 0.08f * s, fx, my + 0.05f * s)
                wp.quadTo(fx + 0.12f * s, my + 0.18f * s, fx + 0.25f * s, my + 0.05f * s)
                c.drawPath(wp, line)
            }
            else -> c.drawArc(RectF(fx - 0.22f * s, my - 0.2f * s, fx + 0.22f * s, my + 0.12f * s), 20f, 140f, false, line)
        }
        // bras
        val armLift = if (m == 2) -abs(sin(time * 12f)) * s * 0.35f else 0f
        fill.color = bodyCol
        for (sx in intArrayOf(-1, 1)) {
            val ax = sx * bw * 1.0f
            val ay = -bh * 0.38f + armLift
            c.drawCircle(ax, ay, s * 0.2f, fill)
            line.color = dark
            line.strokeWidth = max(dp(2f), s * 0.05f)
            c.drawCircle(ax, ay, s * 0.2f, line)
        }
        c.restore()

        // effets d'humeur
        val headY = groundY - jump - bh * bs
        if (m == 4) {
            emoji(c, "🤒", cx, headY - s * 0.5f + sin(time * 3f) * dp(3f), dp(32f))
        } else if (m == 1) {
            val need = when {
                hunger < 30f -> "🍖"
                happy < 30f -> "🎾"
                poops.size >= 2 -> "🧽"
                else -> null
            }
            if (need != null) {
                val bx = cx + bw * 0.9f
                val by = headY - s * 0.4f + sin(time * 2f) * dp(3f)
                fill.color = Color.argb(235, 255, 255, 255)
                c.drawCircle(bx - dp(14f), by + dp(26f), dp(4f), fill)
                c.drawCircle(bx - dp(6f), by + dp(14f), dp(6f), fill)
                c.drawCircle(bx + dp(6f), by, dp(20f), fill)
                emoji(c, need, bx + dp(6f), by, dp(22f))
            }
        }
        // nourriture qui tombe vers la bouche
        if (eatT > 0f) {
            val t = 1f - eatT / 1.6f
            if (t < 0.6f) {
                val k = t / 0.6f
                val fy = (groundY - bh * 1.5f) * (1f - k) + (groundY - bh * 0.42f) * k
                emoji(c, foodEmoji, cx, fy, dp(30f))
            }
        }
    }

    private fun drawZzz(c: Canvas) {
        val dm = dims(gene.shape)
        for (i in 0..2) {
            val t = (time * 0.7f + i / 3f) % 1f
            val x = cx + dm[0] * 0.5f + t * u * 0.8f
            val y = groundY - dm[1] * 0.95f - t * u * 1.2f
            label(c, "Z", x, y, dp(14f) + i * dp(4f) + t * dp(10f), Color.WHITE, true, ((1f - t) * 255).toInt())
        }
    }

    private fun drawHud(c: Canvas) {
        val m = dp(12f)
        val top = dp(30f)
        val hh = dp(44f)
        fill.color = Color.argb(205, 255, 255, 255)
        c.drawRoundRect(RectF(m, top, W - m, top + hh), dp(14f), dp(14f), fill)
        val vals = floatArrayOf(hunger, happy, health)
        val icons = arrayOf("🍖", "😊", "❤️")
        val pad = dp(10f)
        val cw = (W - 2f * m - 2f * pad) / 3f
        val cy = top + hh / 2f
        for (i in 0..2) {
            val x0 = m + pad + cw * i
            emoji(c, icons[i], x0 + dp(10f), cy, dp(18f), if (stage == 2) 255 else 110)
            val bx = x0 + dp(26f)
            val bwid = cw - dp(26f) - dp(8f)
            val bhh = dp(9f)
            fill.color = Color.argb(60, 0, 0, 0)
            c.drawRoundRect(RectF(bx, cy - bhh / 2f, bx + bwid, cy + bhh / 2f), bhh / 2f, bhh / 2f, fill)
            if (stage == 2) {
                val v = vals[i]
                fill.color = when {
                    v > 50f -> 0xFF66BB6A.toInt()
                    v > 25f -> 0xFFFFA726.toInt()
                    else -> 0xFFEF5350.toInt()
                }
                val fw = max(bhh, bwid * v / 100f)
                c.drawRoundRect(RectF(bx, cy - bhh / 2f, bx + fw, cy + bhh / 2f), bhh / 2f, bhh / 2f, fill)
            }
        }
        if (stage == 2) {
            label(c, gene.name, W / 2f, resetBtn.centerY(), dp(16f), 0xFF5D3A1A.toInt(), true)
        }
        // bouton nouvel œuf
        fill.color = if (resetArmT > 0f) 0xFFEF5350.toInt() else Color.argb(170, 255, 255, 255)
        c.drawCircle(resetBtn.centerX(), resetBtn.centerY(), resetBtn.width() / 2f, fill)
        label(c, "↻", resetBtn.centerX(), resetBtn.centerY(), dp(20f), if (resetArmT > 0f) Color.WHITE else 0xFF5D3A1A.toInt(), true)
    }

    private fun drawPanel(c: Canvas) {
        fill.color = 0xFF3B2A4F.toInt()
        c.drawRect(0f, roomH, W, H, fill)
        fill.color = 0xFF54406E.toInt()
        c.drawRect(0f, roomH, W, roomH + dp(4f), fill)
        val enabled = stage == 2
        val names = arrayOf(
            if (sick) "Soigner" else "Nourrir",
            "Jeu",
            "Nettoyage",
            if (sleeping) "Lumière" else "Sommeil"
        )
        val icons = arrayOf(
            if (sick) "💊" else "🍎",
            "🎾",
            "🧽",
            if (sleeping) "💡" else "🌙"
        )
        for (i in 0..3) {
            val r = btn[i]
            c.save()
            if (pressT[i] > 0f) c.scale(0.94f, 0.94f, r.centerX(), r.centerY())
            val a = if (enabled) 255 else 100
            fill.color = mix(btnColors[i], Color.BLACK, 0.35f)
            fill.alpha = a
            c.drawRoundRect(RectF(r.left, r.top + dp(4f), r.right, r.bottom + dp(4f)), dp(16f), dp(16f), fill)
            fill.color = btnColors[i]
            fill.alpha = a
            c.drawRoundRect(r, dp(16f), dp(16f), fill)
            fill.alpha = 255
            emoji(c, icons[i], r.centerX(), r.centerY() - dp(8f), min(r.height() * 0.42f, dp(36f)), a)
            label(c, names[i], r.centerX(), r.bottom - dp(16f), dp(12f), Color.WHITE, true, a)
            c.restore()
        }
    }

    private fun drawMessage(c: Canvas) {
        if (msgT <= 0f || msg.isEmpty()) return
        val a = (min(1f, msgT / 0.4f) * 255).toInt()
        txt.textSize = dp(14f)
        txt.typeface = Typeface.DEFAULT_BOLD
        val tw = txt.measureText(msg)
        val py = roomH - dp(26f)
        fill.color = Color.argb(a * 170 / 255, 20, 20, 40)
        c.drawRoundRect(RectF(W / 2f - tw / 2f - dp(14f), py - dp(16f), W / 2f + tw / 2f + dp(14f), py + dp(16f)), dp(16f), dp(16f), fill)
        label(c, msg, W / 2f, py, dp(14f), Color.WHITE, true, a)
    }
}
